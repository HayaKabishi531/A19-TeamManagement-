this github include the server and client sides

for the website : https://a19-team-management-w1ax.vercel.app/

exist accounts you can Login :

    email                   password
admin@gmail.com              admin

ronen@gmail.com              ronen

adham@gmail.com              adham

daniella@gmail.com           daniella

layan@gmail.com              layan

haya@gmail.com               haya

