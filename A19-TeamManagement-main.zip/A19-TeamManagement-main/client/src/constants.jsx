

// const url = "http://localhost:3001"
const url = "https://a19-team-management.vercel.app"

export const API_URL = url